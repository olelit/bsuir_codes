#pragma once

namespace CppCLRWinformsProjekt {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Zusammenfassung f�r Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Konstruktorcode hier hinzuf�gen.
			//
		}

	protected:
		/// <summary>
		/// Verwendete Ressourcen bereinigen.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::Button^ button1;
	protected:

	private:
		/// <summary>
		/// Erforderliche Designervariable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Erforderliche Methode f�r die Designerunterst�tzung.
		/// Der Inhalt der Methode darf nicht mit dem Code-Editor ge�ndert werden.
		/// </summary>
		void InitializeComponent(void)
		{
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// pictureBox1
			// 
			this->pictureBox1->Location = System::Drawing::Point(155, 12);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(1159, 617);
			this->pictureBox1->TabIndex = 0;
			this->pictureBox1->TabStop = false;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(33, 360);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 1;
			this->button1->Text = L"button1";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1326, 641);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->pictureBox1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);

		}
		//
#pragma endregion

	private: 
		
		
		System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {

		Graphics^ g = pictureBox1->CreateGraphics();
		Pen^ bluePen = gcnew Pen(Color::Blue, 1.0f);
		Pen^ blackPen = gcnew Pen(Color::Black, 1.0f);
		Pen^ greenPen = gcnew Pen(Color::Green, 10.0f);
		Pen^ orangePen = gcnew Pen(Color::Orange, 10.0f);
		Pen^ pinkPen = gcnew Pen(Color::HotPink, 10.0f);

		float step = 250;
		float halfWidht = pictureBox1->Width / 2;
		float halfHeight = pictureBox1->Height / 2;

		g->DrawLine(blackPen, Point(0, halfHeight), Point(pictureBox1->Width, halfHeight));
		g->DrawLine(blackPen, Point(halfWidht-180, 0), Point(halfWidht-180, pictureBox1->Height));

		Generic::List<Point>^ curvePoints = gcnew Generic::List<Point>();
		float a = 200.0f;
		float t = 0.0f;
		float l = 100.0f;



		while (t < 2 * Math::PI)
		{
			float cos_t = Math::Cos(t);
			float sin_t = Math::Sin(t);
			float x = a * (cos_t * cos_t) + (l * cos_t);
			float y = a * cos_t * sin_t + l * sin_t;
			Point point = Point(x+step, y+step);
			curvePoints->Add(point);
			t += 0.01f;
		}
		// Draw polygon to screen
		g->DrawPolygon(bluePen, curvePoints->ToArray());	

		SolidBrush^ backBrush = gcnew SolidBrush(Color::White);
		SolidBrush^ frontBrush = gcnew SolidBrush(Color::AliceBlue);
		SolidBrush^ fontBrush = gcnew SolidBrush(Color::Red);
		System::Drawing::Font^ drawFont = gcnew System::Drawing::Font("Verdana", 12);

		float x_d = 3 * a / 4;
		float y_d = Math::Sqrt(3) * x_d;
		float y_c = y_d;

		float a_x = 2 * a + 148;
		float a_y = halfHeight;
		g->DrawEllipse(orangePen, a_x, a_y, 1.0f, 1.0f); //A
		g->DrawString("A", drawFont, fontBrush, a_x+10, a_y+10);

		float c_x = x_d+230;
		float c_y = y_c-187;
		g->DrawEllipse(greenPen, c_x, c_y, 1.0f, 1.0f); //C
		g->DrawString("�", drawFont, fontBrush, c_x, c_y);

		float d_y = y_c + 166;
		g->DrawEllipse(pinkPen, c_x, d_y, 1.0f, 1.0f); //D
		g->DrawString("D", drawFont, fontBrush, c_x+10, d_y+10 / 2);
		//

		//
		//-step;
		//
	}
	private: System::Void Form1_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	};
}
